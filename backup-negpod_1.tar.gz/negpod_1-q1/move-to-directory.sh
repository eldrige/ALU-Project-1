#!/bin/bash

mkdir negpod_1-q1

mv ./* ./negpod_1-q1

echo "All files moved"